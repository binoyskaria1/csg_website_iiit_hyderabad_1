// config.js
// const apiUrl = 'https://5csglab-production.up.railway.app';
// const apiUrl = 'https://csgiiit.zeabur.app';
const apiUrl = 'https://csg-lab-dev-hhsj.1.sg-1.fl0.io';

// const apiUrl ='https://malamute-devoted-fully.ngrok-free.app';

// const apiUrl = 'https://csg-website.zeabur.app';
